"use client"
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getUser, isAuthed } from '@/lib/auth'
import { ThemeToggle } from '@/components/theme-toggle'

export default function WelcomePage() {
  const router = useRouter()
  const [name, setName] = useState<string>('Member')
  useEffect(() => {
    if (!isAuthed()) router.replace('/login')
    const u = getUser()
    if (u?.name) setName(u.name.split(' ')[0])
  }, [router])

  const cards = [
    { t: 'NYSC Allowance', href: '/app' },
    { t: 'Redeployment Process', href: '/app' },
    { t: 'PPA & Posting', href: '/app' },
    { t: 'Registration & Mobilization', href: '/app' },
  ]

  return (
    <main className="min-h-[100dvh] bg-primary">
      <header className="border-b border-default">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-sm">NYSC AI</div>
          <ThemeToggle />
        </div>
      </header>
      <section className="container mx-auto px-4 py-10">
        <div className="flex flex-col items-center">
          <div className="h-24 w-24 rounded-full bg-secondary border border-default flex items-center justify-center text-3xl">
            {name ? name[0]?.toUpperCase() : 'N'}
          </div>
          <h1 className="mt-4 text-2xl font-semibold">Welcome, {name}</h1>
          <p className="mt-1 text-sm text-secondary">What would you like help with today?</p>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <a
              key={c.t}
              href={c.href}
              className="rounded-2xl border border-default bg-secondary p-6 hover:translate-y-[-2px] transition-transform duration-150"
            >
              <div className="h-10 w-10 rounded-md accent mb-4" />
              <div className="font-medium">{c.t}</div>
              <div className="text-sm text-secondary mt-1">Tap to open</div>
            </a>
          ))}
        </div>
      </section>
      <footer className="mt-10 border-t border-default">
        <div className="py-10 bg-sidebar">
          <div className="container mx-auto px-4 grid gap-8 md:grid-cols-[1.5fr_1fr] items-center">
            <div>
              <div className="text-lg font-semibold">NYSC AI Assistant</div>
              <div className="mt-2 text-sm text-secondary">
                Accurate, official guidance for corps members and prospective members.
              </div>
              <div className="mt-4 text-xs text-secondary">
                support@nysc.ai
              </div>
            </div>
            <div className="flex items-center justify-start md:justify-end gap-4">
              <div className="h-10 w-10 rounded bg-secondary border border-default" />
              <div className="h-10 w-10 rounded bg-secondary border border-default" />
              <div className="h-10 w-10 rounded bg-secondary border border-default" />
            </div>
          </div>
          <div className="container mx-auto px-4 mt-6 text-xs text-secondary flex items-center justify-between">
            <div>© 2026 NYSC AI. All rights reserved.</div>
            <div className="flex gap-3">
              <span>Privacy</span>
              <span>Terms</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}

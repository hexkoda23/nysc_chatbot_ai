"use client"
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ChatMock } from '@/components/chat-mock'
import { motion } from 'framer-motion'
import { GetStartedButton } from '@/components/get-started'

export default function Page() {
  return (
    <main>
      <Header />
      <section className="relative">
        <div className="absolute inset-0 -z-10 opacity-60 blur-3xl bg-[radial-gradient(600px_circle_at_20%_20%,#2BB673_10%,transparent_60%),radial-gradient(700px_circle_at_80%_30%,#0B7A33_10%,transparent_60%)] dark:opacity-30" />
        <div className="container py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1
              initial={false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-5xl md:text-6xl font-bold tracking-tight"
            >
              AI That Understands NYSC.
            </motion.h1>
            <p className="mt-4 text-lg text-slate-700 dark:text-slate-300 max-w-xl">
              Get instant, accurate answers on call-up letters, PPA postings, allowances, mobilization, and official policies.
            </p>
            <div className="mt-6 flex gap-3">
              <GetStartedButton />
              <a href="#demo" className="inline-flex rounded-xl border border-slate-300/60 dark:border-slate-700/60 px-6 py-3">
                View Demo
              </a>
            </div>
            <div className="mt-6 flex gap-4 text-xs text-slate-600 dark:text-slate-400">
              <span className="rounded-full border px-2 py-1">Secure</span>
              <span className="rounded-full border px-2 py-1">Powered by AI</span>
              <span className="rounded-full border px-2 py-1">Always Updated</span>
            </div>
          </div>
          <ChatMock />
        </div>
      </section>

      <section id="features" className="container py-16">
        <h2 className="text-3xl font-semibold">Built for Every NYSC Member</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[
            ['Real-time AI Q&A', 'Accurate, policy-grounded answers at any time.'],
            ['PPA Posting Guidance', 'Navigate PPA placement with context-aware advice.'],
            ['Call-up Letter Help', 'Understand timelines and required documentation.'],
            ['Allowance & Payments', 'Up-to-date allowance and payment guidance.'],
            ['Mobilization Checklist', 'Everything you need before reporting.'],
            ['Multilingual Voice Support', 'Inclusive support that scales nationwide.'],
          ].map(([t, s]) => (
            <motion.div
              key={t}
              initial={false}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="card p-6 hover:shadow-lg transition-shadow"
            >
              <div className="h-8 w-8 rounded-md accent mb-3" />
              <div className="font-medium">{t}</div>
              <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">{s}</div>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="how" className="container py-16">
        <h2 className="text-3xl font-semibold">How It Works</h2>
        <div className="mt-6 grid md:grid-cols-4 gap-4">
          {['Ask a Question','AI Understands Context','Retrieves Official Information','Responds Instantly'].map((t, i) => (
            <motion.div
              key={t}
              initial={false}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="card p-5 relative"
            >
              <div className="text-2xl font-bold accent-text">
                {i+1}
              </div>
              <div className="mt-2 text-sm text-slate-700 dark:text-slate-300">{t}</div>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="demo" className="py-16 bg-primary">
        <div className="container">
          <h2 className="text-3xl font-semibold">Interactive Chat Preview</h2>
          <div className="mt-6">
            <ChatMock />
          </div>
        </div>
      </section>

      <section id="security" className="container py-16">
        <h2 className="text-3xl font-semibold">Secure. Reliable. Built for Accuracy.</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            ['Encrypted Communication','All chat and data exchanges use modern encryption.'],
            ['Verified NYSC Sources','Grounded in official NYSC materials and updates.'],
            ['Continuous Model Updates','Regular improvements for precision and coverage.'],
          ].map(([t, s]) => (
            <div key={t} className="card p-6">
              <div className="h-8 w-8 rounded-md accent mb-3" />
              <div className="font-medium">{t}</div>
              <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">{s}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="container py-16">
        <h2 className="text-3xl font-semibold">What Corps Members Say</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            ['Aisha, Batch B','Got step-by-step redeployment instructions — fast and accurate.'],
            ['Chinedu, Stream II','Simple PPA change steps and accurate N77,000 allowance info.'],
            ['Zainab, Alumni','Reliable answers grounded in official NYSC policy — no guesswork.'],
          ].map(([n, q]) => (
            <div key={n} className="card p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-slate-300 dark:bg-slate-700" />
                <div className="font-medium">{n}</div>
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400 mt-3">“{q}”</div>
            </div>
          ))}
        </div>
      </section>

      <section id="faq" className="container py-16">
        <h2 className="text-3xl font-semibold">FAQ</h2>
        <div className="mt-6 space-y-3">
          {[
            [
              'What do I need to register for NYSC?',
              'You need your NIN, JAMB registration number, matriculation number, a passport photo (white background), and your name on your school’s Senate/Academic Board list. Register on the portal: https://portal.nysc.org.ng/nysc1/ .'
            ],
            [
              'How do I check if my name is on the Senate List?',
              'Open https://portal.nysc.org.ng/nysc2/VerifySenateLists.aspx , select your institution, enter your Matric number, Surname and Date of Birth, then Search. If “No Record Found”, contact your Student Affairs Office.'
            ],
            [
              'How do I print my call‑up letter?',
              'Log in to your NYSC dashboard (https://portal.nysc.org.ng/nysc1/) when posting is released. Click Call‑up Letter and print in colour. Do not laminate; laminated copies are rejected at camp.'
            ],
            [
              'What is the NYSC monthly allowance?',
              'N77,000 per month (from March 2025). Some states and PPAs may pay additional stipends which vary by location and employer.'
            ],
            [
              'Can I apply for redeployment?',
              'Yes. Valid reasons are health, marriage (female only), recognized insecurity states, or DG directive. Apply in camp with documents or via your portal after camp.'
            ],
            [
              'How can I change my PPA?',
              'Obtain a rejection from your current PPA or an acceptance from a new PPA, then submit to your LGI for reposting approval. Continue serving at your current PPA until you receive an official reposting letter.'
            ],
          ].map(([q, a]) => (
            <details key={q} className="card p-4">
              <summary className="font-medium cursor-pointer">{q}</summary>
              <div className="text-sm text-slate-600 dark:text-slate-400 mt-2">{a}</div>
            </details>
          ))}
        </div>
      </section>

      <Footer />
    </main>
  )
}

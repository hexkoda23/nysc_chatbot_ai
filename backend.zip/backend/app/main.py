import os
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["USE_TF"] = "0"
from typing import List, Dict, Any, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from dotenv import load_dotenv
load_dotenv()   # MUST be before os.getenv
 



@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lightweight startup that warms the local corpus for instant retrieval."""
    try:
        from .rag_engine import _load_corpus  # type: ignore
        _ = _load_corpus()
    except Exception:
        pass
    yield


class Source(BaseModel):
    source: str
    snippet: str


class ChatRequest(BaseModel):
    session_id: str
    message: str
    language: Optional[str] = None


class ChatResponse(BaseModel):
    answer: str
    sources: List[Source]
    detected_language: Optional[str] = None
    detected_language_name: Optional[str] = None

class TranslateRequest(BaseModel):
    target_lang: str
    texts: List[str]
    source_lang: Optional[str] = None

class TranslateResponse(BaseModel):
    translations: List[str]


app = FastAPI(
    title="NYSC AI Assistant",
    description="Agentic RAG assistant to help Nigerian youths navigate NYSC.",
    version="0.1.0",
    lifespan=lifespan,
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5179",
        "http://127.0.0.1:5179",
        "http://localhost:5180",
        "http://127.0.0.1:5180",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/api/reload")
def reload_documents() -> Dict[str, str]:
    """
    Reload documents and clear vector store cache.
    Call this after adding new documents to the data directory.
    """
    try:
        from .rag_engine import _load_corpus  # type: ignore
        # Warm corpus cache
        _load_corpus.cache_clear()
        docs = _load_corpus()
        return {
            "status": "success",
            "message": f"Reloaded {len(docs)} document chunks",
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
        }


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    """
    Chat endpoint for the NYSC assistant.

    The same `session_id` should be reused by the frontend to preserve context.
    """
    try:
        # Inline multilingual flow to guarantee answers follow the selected/detected language.
        from .language import detect_language, translate_to_english, translate_from_english, LANG_CODES
        from .rag_engine import run_nysc_agent

        print(f"[CHAT] incoming selectedLang={request.language!r}")

        # Normalise override
        override = request.language
        if override == "auto":
            override = None

        # 1) Detect language of the incoming message
        detected = detect_language(request.message)

        # 2) Decide target language:
        #    - explicit override if valid
        #    - otherwise, use detected
        target = override if (override and override in LANG_CODES) else detected

        print(f"[CHAT] detected={detected} target={target}")

        # 3) Translate user message into English for RAG
        msg_en = translate_to_english(request.message, detected)

        # 4) Run the NYSC agent on English text
        result = run_nysc_agent(message=msg_en, session_id=request.session_id)
        ans_en = result.get("answer", "")
        sources = result.get("sources", [])

        # 5) Translate answer from English into the target language
        final_answer = translate_from_english(ans_en, target)

        print(f"[CHAT] final_target={target} returning_length={len(final_answer)}")

        names = {"en": "English", "yo": "Yoruba", "ig": "Igbo", "ha": "Hausa"}
        return ChatResponse(
            answer=final_answer,
            sources=[Source(**s) for s in sources],
            detected_language=target,
            detected_language_name=names.get(target, "English"),
        )
    except Exception as e:
        import traceback
        error_msg = str(e)
        traceback.print_exc()
        # Fallback: try to answer and still respect the question language as much as possible
        try:
            from .rag_engine import run_nysc_agent
            from .language import detect_language, translate_from_english, LANG_CODES

            result = run_nysc_agent(message=request.message, session_id=request.session_id)
            ans_en = result.get("answer", f"[BACKEND ERROR] {error_msg}")
            sources = result.get("sources", [])

            # Detect language from the original question
            detected = detect_language(request.message)
            override = request.language if request.language != "auto" else None
            target = override if (override and override in LANG_CODES) else detected

            try:
                final_answer = translate_from_english(ans_en, target)
            except Exception:
                final_answer = ans_en

            names = {"en": "English", "yo": "Yoruba", "ig": "Igbo", "ha": "Hausa"}
            return ChatResponse(
                answer=final_answer,
                sources=[Source(**s) for s in sources],
                detected_language=target,
                detected_language_name=names.get(target, "English"),
            )
        except Exception:
            return ChatResponse(
                answer=f"[BACKEND ERROR] {error_msg}",
                sources=[],
            )

@app.post("/api/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest) -> TranslateResponse:
    try:
        from .language import translate_from_english, _translate
        out: List[str] = []
        for t in req.texts:
            if req.source_lang and req.source_lang != "en":
                out.append(_translate(t, req.target_lang, req.source_lang))
            else:
                out.append(translate_from_english(t, req.target_lang))
        return TranslateResponse(translations=out)
    except Exception as e:
        return TranslateResponse(translations=req.texts)


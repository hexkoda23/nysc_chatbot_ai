"use client"
import { useEffect, useRef, useState } from 'react'
import { getUser, isAuthed, signOut } from '@/lib/auth'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Mic, Send, Plus, LogOut, Settings, Search } from 'lucide-react'

type Source = { source: string; snippet: string }
type Msg = { id: string; role: 'user'|'assistant'; content: string; sources?: Source[] }
type Chat = { id: string; title: string; msgs: Msg[] }

const STORAGE_KEY = 'nysc_chats'
const isGreeting = (t: string) => {
  const s = t.trim().toLowerCase()
  return ['hi','hello','hey','good morning','good afternoon','good evening'].some(g => s === g || s.startsWith(g + ' '))
}

export default function ChatApp() {
  const router = useRouter()
  const [chats, setChats] = useState<Chat[]>([])
  const [currentId, setCurrentId] = useState<string>('')
  const [input, setInput] = useState('')
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [showAnonNotice, setShowAnonNotice] = useState(false)
  const [authed, setAuthed] = useState(false)
  const [userName, setUserName] = useState<string | null>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const sessionIdRef = useRef<string>()
  if (!sessionIdRef.current) sessionIdRef.current = crypto.randomUUID()
  const renderContent = (text: string) => {
    const parts = text.split(/(https?:\/\/[^\s]+)/g)
    return parts.map((p, i) => {
      const clean = p.replace(/^`+|`+$/g, '')
      if (/^https?:\/\/[^\s]+$/.test(clean)) {
        return (
          <a
            key={i}
            href={clean}
            target="_blank"
            rel="noopener noreferrer"
            className="underline"
          >
            {clean}
          </a>
        )
      }
      return <span key={i}>{p}</span>
    })
  }

  const API_BASE =
    (typeof process !== 'undefined' &&
      (process.env.NEXT_PUBLIC_API_BASE as string)) ||
    'http://127.0.0.1:8000'

  const filteredChats = query
    ? chats.filter(c => c.title.toLowerCase().includes(query.toLowerCase()))
    : chats
  const current = chats.find(c => c.id === currentId)
  const messages = current?.msgs ?? []

  const persist = (next: Chat[]) => {
    setChats(next)
    if (!authed) return
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)) } catch {}
  }
  const updateMsgContent = (cid: string, mid: string, content: string, sources?: Source[]) => {
    setChats(prev => {
      const next = prev.map(c => {
        if (c.id !== cid) return c
        return {
          ...c,
          msgs: c.msgs.map(m => (m.id === mid ? { ...m, content, sources: sources ?? m.sources } : m)),
        }
      })
      if (authed) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)) } catch {}
      }
      return next
    })
  }
  const typeOut = (text: string, cid: string, mid: string, sources?: Source[]) => {
    setLoading(true)
    const total = text.length
    let i = 0
    const step = total > 2000 ? 4 : total > 1000 ? 3 : 2
    const tick = () => {
      i = Math.min(total, i + step)
      updateMsgContent(cid, mid, text.slice(0, i))
      if (i < total) {
        setTimeout(tick, 16)
      } else {
        updateMsgContent(cid, mid, text, sources)
        setLoading(false)
      }
    }
    tick()
  }

  const newChat = () => {
    const id = crypto.randomUUID()
    const chat: Chat = { id, title: 'New chat', msgs: [] }
    persist([chat, ...chats])
    setCurrentId(id)
  }

  const ensureCurrent = (): Chat => {
    const c = chats.find(x => x.id === currentId)
    if (c) return c
    const id = crypto.randomUUID()
    const chat: Chat = { id, title: 'New chat', msgs: [] }
    const next = [chat, ...chats]
    setCurrentId(id)
    persist(next)
    return chat
  }

  useEffect(() => {
    const a = isAuthed()
    setAuthed(a)
    if (!a) setShowAnonNotice(true)
    const u = getUser()
    setUserName(u?.name || null)
    if (a) {
      try {
        const raw = localStorage.getItem(STORAGE_KEY)
        if (raw) {
          const saved: Chat[] = JSON.parse(raw)
          setChats(saved)
          if (saved.length) setCurrentId(saved[0].id)
          else newChat()
        } else {
          newChat()
        }
      } catch {
        newChat()
      }
    } else {
      newChat()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Ensure backend picks up any new documents by reloading corpus once
  useEffect(() => {
    const base =
      (typeof process !== 'undefined' &&
        (process.env.NEXT_PUBLIC_API_BASE as string)) ||
      'http://127.0.0.1:8000'
    fetch(`${base}/api/reload`, { method: 'POST' }).catch(() => {})
    // fire-and-forget; safe in dev, idempotent on server
  }, [])

  useEffect(() => {
    if (!listRef.current) return
    listRef.current.scrollTop = listRef.current.scrollHeight
  }, [messages, loading])

  const appendMsg = (m: Msg, chatId?: string) => {
    const cid = chatId ?? currentId
    if (!cid) return
    setChats(prev => {
      let found = false
      const next = prev.map(c => {
        if (c.id === cid) {
          found = true
          return { ...c, title: titleFor(c, m), msgs: [...c.msgs, m] }
        }
        return c
      })
      if (!found) {
        const created: Chat = { id: cid, title: m.role === 'user' ? (m.content.split(/\s+/).slice(0, 6).join(' ') || 'New chat') : 'New chat', msgs: [m] }
        next.unshift(created)
      }
      if (authed) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)) } catch {}
      }
      return next
    })
  }

  const titleFor = (c: Chat, m: Msg) => {
    if (c.msgs.length > 0 || m.role !== 'user') return c.title
    const t = m.content.split(/\s+/).slice(0, 6).join(' ')
    return t || 'New chat'
  }

  const send = async () => {
    if (!input.trim() || loading) return
    const target = ensureCurrent()
    const targetId = target.id
    const text = input.trim()
    const userMsg: Msg = { id: crypto.randomUUID(), role: 'user', content: text }
    appendMsg(userMsg, targetId)
    setInput('')

    // Greeting: respond politely immediately
    if (isGreeting(text)) {
      const ai: Msg = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: "Hello! I’m NYSC AI. How can I help today? I can assist with allowances, redeployment, registration and camp questions based on official NYSC documents.",
      }
      appendMsg(ai, targetId)
      return
    }

    setLoading(true)
    try {
      const res = await fetch(`${API_BASE}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionIdRef.current, message: text }),
      })
      const data = await res.json()
      const aiId = crypto.randomUUID()
      const ai: Msg = { id: aiId, role: 'assistant', content: '' }
      appendMsg(ai, targetId)
      typeOut(String(data.answer || ''), targetId, aiId, data.sources || [])
      return
    } catch (e) {
      const ai: Msg = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content:
          'Unable to reach the NYSC assistant. Ensure the backend is running at 127.0.0.1:8000 and CORS allows http://localhost:5180.',
      }
      appendMsg(ai, targetId)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-[100dvh] bg-primary text-primary">
      <div className="flex h-[100dvh]">
        <aside className="hidden md:flex w-72 flex-col border-r border-default p-4 bg-sidebar">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-full bg-secondary border border-default flex items-center justify-center text-sm">
              {userName ? userName[0]?.toUpperCase() : 'N'}
            </div>
            <div className="text-sm">
              <div className="font-medium">{userName || 'NYSC Member'}</div>
              <div className="text-secondary">@nysc</div>
            </div>
          </div>
          <button
            onClick={newChat}
            className="mb-4 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm accent"
            aria-label="Start a new chat"
          >
            <Plus size={16} /> Start a New Chat
          </button>
          <div className="relative mb-3">
            <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-secondary" />
            <input
              className="w-full rounded-lg border border-default bg-secondary px-7 py-1.5 text-sm focus-ring"
              placeholder="Search history"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="text-xs text-secondary mb-1">History</div>
          <div className="flex-1 overflow-y-auto space-y-1 pr-1">
            {filteredChats.map(c => (
              <button
                key={c.id}
                onClick={() => setCurrentId(c.id)}
                className={
                  'w-full text-left px-3 py-2 rounded-lg text-sm transition-colors duration-150 ' +
                  (c.id === currentId ? 'bg-secondary' : 'hover:bg-secondary')
                }
                title={c.title}
              >
                {c.title}
              </button>
            ))}
          </div>
          <div className="mt-3 border-t border-default pt-3 space-y-2">
            <button
              className="w-full inline-flex items-center gap-2 rounded-lg border border-default bg-secondary px-3 py-2 text-left text-sm"
              onClick={() => router.push('/preferences')}
              title="Preferences"
            >
              <Settings size={16} /> Preferences
            </button>
            <button
              className="w-full inline-flex items-center gap-2 rounded-lg border border-default bg-secondary px-3 py-2 text-left text-sm"
              onClick={() => { signOut(); router.replace('/login') }}
              title="Log out"
            >
              <LogOut size={16} /> Log out
            </button>
          </div>
        </aside>

        <section className="flex-1">
          <div className="max-w-3xl mx-auto p-4">
            <div className="mb-4 flex items-center justify-between">
              <button
                onClick={() => router.push('/welcome')}
                className="inline-flex items-center gap-1 rounded-lg border border-default bg-secondary px-3 py-1.5 text-sm"
              >
                <ArrowLeft size={16} /> Back
              </button>
              <select className="rounded-lg border border-default bg-secondary text-sm px-2 py-1">
                <option>English</option>
              </select>
            </div>
            {showAnonNotice && (
              <div className="mb-3 rounded-xl border border-amber-300 bg-amber-50 text-amber-900 px-4 py-3 text-xs">
                Chats aren’t saved. <a className="underline" href="/signup">Sign up</a> or <a className="underline" href="/login">log in</a> to store history.
                <button onClick={() => setShowAnonNotice(false)} className="float-right underline">Dismiss</button>
              </div>
            )}

            <div className="rounded-2xl border border-default bg-secondary p-0 shadow-xl">
              <div className="p-6">
                <div className="mb-4 text-center">
                  <h2 className="text-2xl md:text-3xl font-semibold">How can I assist you today?</h2>
                </div>
                <div ref={listRef} className="h-[58vh] overflow-y-auto space-y-4">
                  {messages.length === 0 && (
                    <div className="grid gap-3 sm:grid-cols-2">
                      {[
                        ['How do I apply for redeployment?', 'valid reasons and steps'],
                        ['What are the camp registration requirements?', 'documents and eligibility'],
                        ['How can I change my PPA?', 'process and approvals'],
                        ['What is the current NYSC allowance?', 'monthly amount and timing'],
                        ['How do I print my call-up letter?', 'portal and timelines'],
                        ['What is the posting policy?', 'serving outside state of origin'],
                      ].map(([t, sub]) => (
                        <button
                          key={t}
                          onClick={() => setInput(t)}
                          className="rounded-xl border border-default bg-primary px-4 py-3 text-left hover:translate-y-[-1px] transition-transform duration-150"
                        >
                          <div className="text-sm">{t}</div>
                          <div className="text-xs text-secondary">{sub}</div>
                        </button>
                      ))}
                    </div>
                  )}
                  {messages.map((m) => (
                    <div key={m.id} className={m.role === 'user' ? 'text-right' : 'text-left'}>
                      <div
                        className={
                          'inline-block max-w-[80%] rounded-2xl px-4 py-2 text-sm leading-relaxed transition-colors duration-150 ' +
                          (m.role === 'user'
                            ? 'accent'
                            : 'bg-secondary border border-default whitespace-pre-wrap')
                        }
                      >
                        {renderContent(m.content)}
                      </div>
                    </div>
                  ))}
                  {loading && <div className="text-xs text-secondary">Typing…</div>}
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <button
                    className="h-10 w-10 inline-flex items-center justify-center rounded-full border border-default bg-primary"
                    title="Voice input"
                  >
                    <Mic size={18} />
                  </button>
                  <input
                    className="flex-1 rounded-full border border-default px-4 py-2 bg-primary text-primary focus-ring"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask me anything about NYSC…"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault(); send()
                      }
                    }}
                  />
                  <button
                    onClick={send}
                    disabled={loading || !input.trim()}
                    className="h-10 w-10 inline-flex items-center justify-center rounded-full accent disabled:opacity-50"
                    aria-label="Send"
                  >
                    <Send size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}

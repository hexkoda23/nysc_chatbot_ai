import re
from typing import List, Dict, Tuple, Optional
from .rag_engine import run_nysc_agent, _make_llm

LANG_CODES = {"en", "yo", "ig", "ha"}

def _detect_language_heuristic(text: str) -> str:
    t = text.strip().lower()
    if not t:
        return "en"
    yo_markers = ["e kaaro", "e kaasan", "e kuurole", "bawo", "báwo", "ẹ", "ṣ", "ọ", "ò", "á"]
    ig_markers = ["kedu", "unu", "ndị", "ị", "ọ", "ụ", "ń", "á"]
    ha_markers = ["sannu", "yaya", "ƙ", "ɗ", "’yan", "zaki"]
    for m in yo_markers:
        if m in t:
            return "yo"
    for m in ig_markers:
        if m in t:
            return "ig"
    for m in ha_markers:
        if m in t:
            return "ha"
    return "en"

def _detect_language_llm(text: str) -> Optional[str]:
    try:
        llm = _make_llm(timeout=8.0, retries=0)
        prompt = (
            "Detect which language the following text is written in.\n"
            "Allowed outputs: en, yo, ig, ha.\n"
            "Return ONLY one of: en, yo, ig, ha.\n\n"
            f"Text:\n{text}\n\nLanguage code:"
        )
        resp = llm.invoke(prompt)
        out = resp.content if hasattr(resp, "content") else str(resp)
        code = out.strip().lower()
        if code in {"en", "yo", "ig", "ha"}:
            return code
    except Exception:
        pass
    return None

def _mask_urls(text: str) -> Tuple[str, List[str]]:
    urls = re.findall(r"https?://[^\s]+", text)
    masked = text
    for i, u in enumerate(urls):
        masked = masked.replace(u, f"[[URL{i}]]")
    return masked, urls

def _unmask_urls(text: str, urls: List[str]) -> str:
    out = text
    for i, u in enumerate(urls):
        out = out.replace(f"[[URL{i}]]", u)
    return out

def _translate(text: str, target_lang: str, source_lang: Optional[str] = None) -> str:
    try:
        if target_lang == "en" and (source_lang in (None, "en")):
            print(f"[TRANSLATE] Skipped (en->en). source={source_lang} target={target_lang}")
            return text
        llm = _make_llm(timeout=18.0, retries=0)
        masked, urls = _mask_urls(text)
        prompt = (
            "Translate the following text accurately. Do not add explanations.\n"
            "Return the output ENTIRELY in the target language — NEVER in English.\n"
            "Translate section labels and hints (e.g., 'Official Source:', 'You may also ask:').\n"
            "Do not translate NYSC proper nouns: NYSC, PPA, LGI, Corps Member, SAED, CDS.\n"
            "Keep any [[URL0]], [[URL1]] placeholders unchanged.\n"
            f"Source language: {source_lang or 'auto'}\nTarget language: {target_lang}\n\n"
            f"Text:\n{masked}\n\nTranslation:"
        )
        print(f"[TRANSLATE] Calling LLM. source={source_lang or 'auto'} target={target_lang}")
        resp = llm.invoke(prompt)
        out = resp.content if hasattr(resp, "content") else str(resp)
        out = out.strip()
        if not out:
            print(f"[TRANSLATE] Empty result from LLM. Returning failure marker.")
            return "[TRANSLATION FAILED] " + text
        # Heuristic: if target is non-English but output looks English, try a stricter retry
        def _looks_english(s: str) -> bool:
            # Exclude NYSC domain words that survive translation intentionally
            nysc_domain = {"portal", "website", "official", "source", "nysc", "ppa", "lgi", "saed", "cds"}
            # Only count general English structural words — not domain nouns
            en_structural = ["the", "and", "to", "you", "your", "steps", "can", "will", "if", "in", "of", "is", "are"]
            s_low = s.lower()
            hits = sum(1 for w in en_structural if f" {w} " in f" {s_low} ")
            has_diacritics = any(ch in s for ch in ("ẹ","ṣ","ọ","ò","á","ị","ụ","ƙ","ɗ","ń","ù","è","ě"))
            # Require more structural hits AND no diacritics to flag as English
            return hits >= 5 and not has_diacritics
        if target_lang != "en" and _looks_english(out):
            print(f"[TRANSLATE] Output appears English; retrying with stricter instruction. target={target_lang}")
            stricter = (
                "Translate strictly into the target language. Never use English words.\n"
                "Translate headings and labels as well (e.g., 'Official Source:', 'You may also ask:').\n"
                "Do not translate proper nouns (NYSC, PPA, LGI, SAED, CDS). Keep [[URL0]] placeholders.\n"
                f"Target: {target_lang}\n\nText:\n{masked}\n\nTranslation:"
            )
            try:
                resp2 = llm.invoke(stricter)
                out2 = resp2.content if hasattr(resp2, "content") else str(resp2)
                out2 = out2.strip() or out
                out = out2
            except Exception as e2:
                print(f"[TRANSLATE] Retry failed: {e2}")
            # If still English-like, try alternate models
            if _looks_english(out):
                print(f"[TRANSLATE] Output still appears English; trying alternate models.")
                for alt in ["llama-3.1-8b-instant", "mixtral-8x7b-32768"]:
                    try:
                        llm_alt = _make_llm(timeout=18.0, retries=0, model_override=alt)
                        resp_alt = llm_alt.invoke(stricter)
                        out_alt = resp_alt.content if hasattr(resp_alt, "content") else str(resp_alt)
                        out_alt = out_alt.strip()
                        if out_alt and not _looks_english(out_alt):
                            out = out_alt
                            print(f"[TRANSLATE] Alternate model produced non-English output: {alt}")
                            break
                    except Exception as e_alt:
                        print(f"[TRANSLATE] Alternate model failed: {alt} err={e_alt}")
        return _unmask_urls(out, urls)
    except Exception as e:
        print(f"[TRANSLATE] ERROR: {e}. Returning failure marker.")
        return "[TRANSLATION FAILED] " + text

def detect_language(text: str) -> str:
    # First pass: fast heuristics
    h = _detect_language_heuristic(text)
    if h != "en":
        return h
    # Check for diacritics indicating local languages
    if any(ch in text for ch in ("ẹ", "ṣ", "ọ", "ò", "á", "ị", "ụ", "ƙ", "ɗ")):
        # Attempt to classify via simple mapping
        yo_chars = {"ẹ", "ṣ", "ọ", "ò", "á"}
        ig_chars = {"ị", "ọ", "ụ"}
        ha_chars = {"ƙ", "ɗ"}
        if any(ch in text for ch in yo_chars):
            return "yo"
        if any(ch in text for ch in ig_chars):
            return "ig"
        if any(ch in text for ch in ha_chars):
            return "ha"
    # Fallback: LLM classification for ambiguous inputs
    llm_code = _detect_language_llm(text)
    return llm_code or "en"

def translate_to_english(text: str, source_lang: str) -> str:
    if source_lang == "en":
        return text
    return _translate(text, "en", source_lang)

def translate_from_english(text: str, target_lang: str) -> str:
    if target_lang == "en":
        return text
    return _translate(text, target_lang, "en")

def process_multilingual_request(message: str, session_id: str, language_override: Optional[str]) -> Tuple[str, str, str, List[Dict[str, str]]]:
    # Normalize 'auto' from frontend to None
    if language_override == "auto":
        language_override = None
    # Detect language of message
    detected = detect_language(message)
    # Target language priority:
    # 1) If override provided and valid -> use override
    # 2) Else use detected language
    target = language_override if (language_override and language_override in LANG_CODES) else detected
    # Always translate pipeline (even if en), but translation function will skip en->en
    print(f"[LANG] selected={language_override} detected={detected} target={target} (pre-translation)")
    msg_en = translate_to_english(message, detected)
    result = run_nysc_agent(message=msg_en, session_id=session_id)
    ans_en = result["answer"]
    sources = result.get("sources", [])
    translated = translate_from_english(ans_en, target)
    print(f"[LANG] translated_length={len(translated)} target={target} (post-translation)")
    return translated, target, msg_en, sources

"use client"
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { isAuthed, signInOrUp } from '@/lib/auth'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

export default function SignupPage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (isAuthed()) router.replace('/welcome')
  }, [router])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      if (!name || !email || !password) throw new Error('Fill in all fields')
      signInOrUp({ name, email })
      router.replace('/welcome')
    } catch (err: any) {
      setError(err?.message || 'Unable to sign up')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-[100dvh] grid md:grid-cols-2">
      <div className="hidden md:flex bg-sidebar relative">
        <div className="absolute inset-0 opacity-60 blur-3xl bg-[radial-gradient(600px_circle_at_20%_20%,_var(--accent-start)_10%,transparent_60%),radial-gradient(700px_circle_at_80%_30%,_var(--accent-end)_10%,transparent_60%)]" />
        <div className="absolute bottom-4 left-4 flex items-center gap-3 text-secondary">
          <div className="h-10 w-10 rounded-full bg-secondary" />
          <div className="h-10 w-10 rounded-full bg-secondary" />
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-[92%] max-w-md rounded-2xl elevated shadow-xl p-6">
          <div className="text-center">
            <div className="text-2xl font-semibold">Create your NYSC AI Account</div>
            <p className="text-sm text-secondary mt-1">Get accurate answers about registration, mobilization, redeployment, PPA and allowances.</p>
          </div>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm mb-1">First Name</label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="First name"
              />
            </div>
            <div>
              <label className="block text-sm mb-1">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-sm mb-1">Password</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            {error && <div className="text-sm text-red-600">{error}</div>}
            <Button type="submit" disabled={loading} className="w-full">
              {loading ? 'Creating account…' : 'Sign Up'}
            </Button>
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 bg-[var(--border-default)]" />
              <div className="text-xs text-secondary">or</div>
              <div className="h-px flex-1 bg-[var(--border-default)]" />
            </div>
            <Button type="button" variant="outline" className="w-full">Sign up with Google</Button>
            <div className="text-xs text-center text-secondary">
              Already have an account? <a className="underline" href="/login">Login</a>
            </div>
          </form>
        </div>
      </div>
    </main>
  )
}
